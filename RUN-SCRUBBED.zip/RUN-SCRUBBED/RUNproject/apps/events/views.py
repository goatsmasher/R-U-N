from django.shortcuts import render, redirect
from ..users.models import User

# Create your views here.
def create(request):
    return render(request, 'main_app/event_page.html')
