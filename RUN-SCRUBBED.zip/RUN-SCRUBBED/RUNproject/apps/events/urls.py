from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^event_page$', views.create, name='create'),
]