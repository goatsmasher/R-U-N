from __future__ import unicode_literals

from django.apps import AppConfig


class MainAppConfig(AppConfig):
    name = 'main_app'
