from django.shortcuts import render, redirect
import re, bcrypt, datetime
from ..users.models import User
from .weather_api import Weather
from .google_maps import geocode


def index(request):
    try: 
        request.session['logged_in'] = True
    except:
        return redirect('user:index')
    return render(request, 'main_app/index.html')

